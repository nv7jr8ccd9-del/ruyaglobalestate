# Rüya Global Estate Premium Website

Upload all files to the GitHub repository root.

Admin panel: `/admin/`

To enable editing:
1. Netlify > Site configuration > Identity > Enable Identity.
2. Identity > Services > Enable Git Gateway.
3. Invite your email as admin.
4. Open `https://yourdomain.com/admin/`.

Google Analytics:
- Add your Measurement ID in Admin > Website Settings > Google Analytics Measurement ID.
